export default {
  showHelpers: false,
  hints: 0,
  skips: 1,
  usedHint: false,
  usedSkip: false,
};