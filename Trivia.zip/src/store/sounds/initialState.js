export default {
  muted: false,
  sounds: {},
  playingSounds: [],
};
