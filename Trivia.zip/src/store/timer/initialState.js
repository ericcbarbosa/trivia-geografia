export default {
  gameTimer: 0,
  levelTimer: 3 * 60 * 1000, // 3 minutos em Milisegundos
};
