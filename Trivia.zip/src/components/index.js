import Ajuda from './Ajuda/Ajuda';
import EndGameFeedback from './Feedback/EndGameFeedback';
import Timer from './Timer/Timer';
import SoundPlayer from './SoundPlayer/SoundPlayer';

export {
  Ajuda,
  EndGameFeedback,
  SoundPlayer,
  Timer,
}