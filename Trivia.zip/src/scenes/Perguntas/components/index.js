import Perguntas from '../Perguntas';
import Images from './Images';
import ImageModal from './ImageModal';
import Opcoes from './Opcoes';
import Feedback from './Feedback';
import Hud from './Hud';

export {
  Perguntas,
  Images,
  ImageModal,
  Opcoes,
  Feedback,
  Hud,
}
