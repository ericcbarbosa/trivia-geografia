import Avatar from './Avatar/';
import Capa from './Capa/Capa';
import Hud from './Hud/Hud';
import Game from './Game/Game';
import Perguntas from './Perguntas/Perguntas';

export {
  Avatar,
  Game,
  Capa,
  Hud,
  Perguntas,
}